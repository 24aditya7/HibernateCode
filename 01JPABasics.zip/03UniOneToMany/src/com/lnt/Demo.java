package com.lnt;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class Demo {

	public static void main(String[] args) {
		Employee employee=new Employee(123, "Jagadeesh", 123456);
		Address address1=new Address(100, "Mumbai", "India");
		Address address2=new Address(101, "Bangalore", "India");
		
		ArrayList<Address> addresses=new ArrayList<Address>();
		addresses.add(address1);
		addresses.add(address2);
		
		employee.setAddresses(addresses);
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa");
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(employee);
		//em.persist(address);
		em.getTransaction().commit();
		em.close();
		emf.close();
		System.out.println("Success..!");
	}

}