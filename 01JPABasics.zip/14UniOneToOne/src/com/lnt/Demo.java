package com.lnt;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Demo {

	public static void main(String[] args) {
		Employee employee=new Employee(123, "Jagadeesh", 123456);
		Address address=new Address(100, "Mumbai", "India");
		employee.setAddress(address);
		
		Configuration configuration=new Configuration();
		configuration=configuration.configure();
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		session.save(employee);
		session.getTransaction().commit();
		session.close();
		sessionFactory.close();
		
	}

}