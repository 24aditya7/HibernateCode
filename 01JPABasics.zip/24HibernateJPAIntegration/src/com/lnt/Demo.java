package com.lnt;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


public class Demo {

	public static void main(String[] args) {

		Employee employee=new Employee(123, "def", 123456);
		
		Address address=new Address("mumbai", "India");
		
		employee.setAddress(address);
		
		
		Configuration configuration=new Configuration();
		configuration=configuration.configure();
		SessionFactory sessionFactory=configuration.buildSessionFactory();//EMF JPA   Configuration
		Session session=sessionFactory.openSession();//EM
		session.beginTransaction();
		session.saveOrUpdate(employee);
		session.getTransaction().commit();
		session.close();
		sessionFactory.close();
		
	}

}