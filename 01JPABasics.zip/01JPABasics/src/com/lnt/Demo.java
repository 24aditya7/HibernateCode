package com.lnt;
import java.util.ArrayList;
import java.util.HashSet;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
public class Demo {

	public static void main(String[] args) {
		
		/*Employee employee=new Employee(131, "abc", 123456);
		Address address=new Address("Mumbai", "India");
		employee.setAddress(address);
		
		ArrayList<String> emails=new ArrayList<String>();
		emails.add("x@gmail.com");
		emails.add("y@gmail.com");
		emails.add("z@gmail.com");
		emails.add("x@gmail.com");
		
		employee.setEmails(emails);*/
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		et.begin();
		Employee employee=em.find(Employee.class, 131);
		et.commit();
		em.close();
		System.out.println("Success..!");
	}

}