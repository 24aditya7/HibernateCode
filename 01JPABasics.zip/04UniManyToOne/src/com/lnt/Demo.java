package com.lnt;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class Demo {

	public static void main(String[] args) {
		
		Employee employee1=new Employee(123, "abc", 123456);
		Employee employee2=new Employee(234, "def", 234567);
		
		Address address=new Address(100, "Mumbai", "India");
		
		employee1.setAddress(address);
		employee2.setAddress(address);
		
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa");
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
		
		em.persist(employee1);
		em.persist(employee2);
		
		
		em.getTransaction().commit();
		em.close();
		emf.close();
		System.out.println("Success..!");
	}

}