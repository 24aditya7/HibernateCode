package com.lnt;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;


public class Demo {

	public static void main(String[] args) {
		Employee employee=new Employee(123, "Jagadeesh", 123456);
		Address address=new Address(100, "Mumbai", "India");
		
		employee.setAddress(address);
		
		address.setEmployee(employee);
		
		Session session=new Configuration().configure().buildSessionFactory().openSession();
		session.beginTransaction();
		session.save(employee);
		session.getTransaction().commit();
		session.close();
		System.out.println("Success..!");
	}

}